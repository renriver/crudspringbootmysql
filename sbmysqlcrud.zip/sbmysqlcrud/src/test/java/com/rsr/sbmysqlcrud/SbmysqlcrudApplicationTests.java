package com.rsr.sbmysqlcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbmysqlcrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
