package com.rsr.sbmysqlcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbmysqlcrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbmysqlcrudApplication.class, args);
	}

}
